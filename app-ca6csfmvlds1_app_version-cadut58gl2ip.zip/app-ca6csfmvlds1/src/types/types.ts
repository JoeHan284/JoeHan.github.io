// 用户相关类型
export type UserRole = "user" | "admin";

export interface Profile {
  id: string;
  email: string | null;
  phone: string | null;
  username: string | null;
  full_name: string | null;
  avatar_url: string | null;
  role: UserRole;
  risk_preference: "conservative" | "moderate" | "aggressive" | null;
  investment_horizon: "short" | "medium" | "long" | null;
  created_at: string;
  updated_at: string;
}

// 资产相关类型
export type AssetType = "stock" | "fund" | "bond" | "deposit";

export interface Asset {
  id: string;
  user_id: string;
  name: string;
  code: string | null;
  asset_type: AssetType;
  quantity: number;
  cost_price: number;
  current_price: number;
  market_value: number;
  profit_loss: number;
  profit_loss_rate: number;
  created_at: string;
  updated_at: string;
}

// 理财产品类型
export type ProductType = "money_market" | "bond_fund" | "stock_fund" | "fixed_income";
export type RiskLevel = "R1" | "R2" | "R3" | "R4" | "R5";

export interface Product {
  id: string;
  name: string;
  code: string;
  product_type: ProductType;
  risk_level: RiskLevel;
  annual_return: number;
  min_purchase: number;
  nav: number;
  description: string | null;
  fund_company: string | null;
  inception_date: string | null;
  total_assets: number | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface ProductNavHistory {
  id: string;
  product_id: string;
  nav: number;
  date: string;
}

// 资讯文章类型
export type ArticleCategory = "news" | "analysis" | "strategy";

export interface Article {
  id: string;
  title: string;
  summary: string | null;
  content: string;
  category: ArticleCategory;
  author: string | null;
  cover_image: string | null;
  view_count: number;
  is_published: boolean;
  published_at: string | null;
  created_at: string;
}

// 交易记录类型
export type TransactionType = "buy" | "sell" | "deposit" | "withdraw";

export interface Transaction {
  id: string;
  user_id: string;
  product_id: string | null;
  product_name: string;
  transaction_type: TransactionType;
  amount: number;
  quantity: number | null;
  price: number | null;
  status: "pending" | "completed" | "cancelled";
  created_at: string;
}

// 财富规划类型
export interface RetirementPlan {
  currentAge: number;
  retirementAge: number;
  monthlyExpense: number;
  lifeExpectancy: number;
  annualReturn: number;
  currentSavings: number;
}

export interface EducationPlan {
  childAge: number;
  educationStartAge: number;
  annualCost: number;
  years: number;
  annualReturn: number;
  currentSavings: number;
}
