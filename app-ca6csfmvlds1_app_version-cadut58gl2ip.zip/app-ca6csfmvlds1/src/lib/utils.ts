import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export type Params = Partial<
  Record<keyof URLSearchParams, string | number | null | undefined>
>;

export function createQueryString(
  params: Params,
  searchParams: URLSearchParams
) {
  const newSearchParams = new URLSearchParams(searchParams?.toString());

  for (const [key, value] of Object.entries(params)) {
    if (value === null || value === undefined) {
      newSearchParams.delete(key);
    } else {
      newSearchParams.set(key, String(value));
    }
  }

  return newSearchParams.toString();
}

export function formatDate(
  date: Date | string | number,
  opts: Intl.DateTimeFormatOptions = {}
) {
  return new Intl.DateTimeFormat("zh-CN", {
    month: opts.month ?? "long",
    day: opts.day ?? "numeric",
    year: opts.year ?? "numeric",
    ...opts,
  }).format(new Date(date));
}

// ── 格式化金额 ─────────────────────────────────────────────
export function formatCNY(value: number, decimals = 2): string {
  if (value >= 100000000) return `${(value / 100000000).toFixed(2)}亿`;
  if (value >= 10000) return `${(value / 10000).toFixed(decimals)}万`;
  return value.toFixed(decimals);
}

// ── 格式化百分比 ───────────────────────────────────────────
export function formatPercent(value: number): string {
  return `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
}

// ── 涨跌颜色类名 ───────────────────────────────────────────
export function riseOrFall(value: number): string {
  if (value > 0) return "text-rise";
  if (value < 0) return "text-fall";
  return "text-muted-foreground";
}

// ── 相对时间 ───────────────────────────────────────────────
export function formatRelativeTime(dateStr: string): string {
  const now = new Date();
  const date = new Date(dateStr);
  const diffMs = now.getTime() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return "刚刚";
  if (diffMin < 60) return `${diffMin}分钟前`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}小时前`;
  const diffDay = Math.floor(diffHr / 24);
  if (diffDay < 30) return `${diffDay}天前`;
  return formatDate(dateStr);
}

// ── 文章分类标签 ───────────────────────────────────────────
export function articleCategoryLabel(cat: string): string {
  const map: Record<string, string> = {
    news: "财经新闻",
    analysis: "市场分析",
    strategy: "投资策略",
  };
  return map[cat] ?? cat;
}

// ── 产品类型标签 ───────────────────────────────────────────
export function productTypeLabel(type: string): string {
  const map: Record<string, string> = {
    money_market: "货币基金",
    bond_fund: "债券基金",
    stock_fund: "股票基金",
    fixed_income: "固收产品",
  };
  return map[type] ?? type;
}

// ── 风险等级标签 ───────────────────────────────────────────
export function riskLevelLabel(level: string): string {
  const map: Record<string, string> = {
    R1: "低风险",
    R2: "中低风险",
    R3: "中风险",
    R4: "中高风险",
    R5: "高风险",
  };
  return map[level] ?? level;
}

// ── 风险等级颜色 ───────────────────────────────────────────
export function riskLevelColor(level: string): string {
  const map: Record<string, string> = {
    R1: "text-fall border-fall/30",
    R2: "text-chart-2 border-chart-2/30",
    R3: "text-chart-3 border-chart-3/30",
    R4: "text-rise border-rise/30",
    R5: "text-destructive border-destructive/30",
  };
  return map[level] ?? "";
}

// ── 资产类型标签 ───────────────────────────────────────────
export function assetTypeLabel(type: string): string {
  const map: Record<string, string> = {
    stock: "股票",
    fund: "基金",
    bond: "债券",
    deposit: "存款",
  };
  return map[type] ?? type;
}

// ── 交易类型标签 ───────────────────────────────────────────
export function transactionTypeLabel(type: string): string {
  const map: Record<string, string> = {
    buy: "买入",
    sell: "卖出",
    deposit: "存入",
    withdraw: "取出",
  };
  return map[type] ?? type;
}

// ── 交易状态标签 ───────────────────────────────────────────
export function transactionStatusLabel(status: string): string {
  const map: Record<string, string> = {
    pending: "处理中",
    completed: "已完成",
    cancelled: "已取消",
  };
  return map[status] ?? status;
}
