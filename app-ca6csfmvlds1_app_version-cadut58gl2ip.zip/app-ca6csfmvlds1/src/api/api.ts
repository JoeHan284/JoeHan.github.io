import { supabase } from "@/db/supabase";
import type {
  Product, Article, Asset, Transaction, Profile, ProductNavHistory,
} from "@/types/types";

// ─── 理财产品 ─────────────────────────────────────────────
export async function fetchProducts(params?: {
  product_type?: string;
  risk_level?: string;
  limit?: number;
  offset?: number;
}) {
  let query = supabase
    .from("products")
    .select("*")
    .eq("is_active", true)
    .order("annual_return", { ascending: false });

  if (params?.product_type && params.product_type !== "all") {
    query = query.eq("product_type", params.product_type);
  }
  if (params?.risk_level && params.risk_level !== "all") {
    query = query.eq("risk_level", params.risk_level);
  }
  query = query.limit(params?.limit ?? 20);
  if (params?.offset) query = query.range(params.offset, params.offset + (params.limit ?? 20) - 1);

  const { data, error } = await query;
  if (error) throw error;
  return Array.isArray(data) ? data as Product[] : [];
}

export async function fetchProductById(id: string) {
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .eq("id", id)
    .maybeSingle();
  if (error) throw error;
  return data as Product | null;
}

export async function fetchProductNavHistory(productId: string, limit = 90) {
  const { data, error } = await supabase
    .from("product_nav_history")
    .select("*")
    .eq("product_id", productId)
    .order("date", { ascending: true })
    .limit(limit);
  if (error) throw error;
  return Array.isArray(data) ? data as ProductNavHistory[] : [];
}

// ─── 资讯文章 ─────────────────────────────────────────────
export async function fetchArticles(params?: {
  category?: string;
  limit?: number;
  offset?: number;
}) {
  let query = supabase
    .from("articles")
    .select("id,title,summary,category,author,cover_image,view_count,published_at,created_at")
    .eq("is_published", true)
    .order("published_at", { ascending: false });

  if (params?.category && params.category !== "all") {
    query = query.eq("category", params.category);
  }
  query = query.limit(params?.limit ?? 20);
  if (params?.offset) query = query.range(params.offset, params.offset + (params.limit ?? 20) - 1);

  const { data, error } = await query;
  if (error) throw error;
  return Array.isArray(data) ? data as Partial<Article>[] : [];
}

export async function fetchArticleById(id: string) {
  const { data, error } = await supabase
    .from("articles")
    .select("*")
    .eq("id", id)
    .maybeSingle();
  if (error) throw error;
  return data as Article | null;
}

// ─── 用户资产 ─────────────────────────────────────────────
export async function fetchAssets(userId: string) {
  const { data, error } = await supabase
    .from("assets")
    .select("*")
    .eq("user_id", userId)
    .order("market_value", { ascending: false })
    .limit(100);
  if (error) throw error;
  return Array.isArray(data) ? data as Asset[] : [];
}

// ─── 交易记录 ─────────────────────────────────────────────
export async function fetchTransactions(userId: string, limit = 20) {
  const { data, error } = await supabase
    .from("transactions")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) throw error;
  return Array.isArray(data) ? data as Transaction[] : [];
}

// ─── 用户资料 ─────────────────────────────────────────────
export async function updateProfile(
  userId: string,
  updates: Partial<Pick<Profile, "username" | "full_name" | "risk_preference" | "investment_horizon">>
) {
  const { error } = await supabase
    .from("profiles")
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq("id", userId);
  if (error) throw error;
}
