import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  TrendingUp, TrendingDown, ArrowRight, BarChart2,
  PieChart, Package, BookOpen, Shield, Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/contexts/AuthContext";
import { fetchArticles, fetchProducts } from "@/api/api";
import { formatCNY, formatPercent, riseOrFall, formatRelativeTime, articleCategoryLabel, productTypeLabel, riskLevelLabel, riskLevelColor } from "@/lib/utils";
import type { Article, Product } from "@/types/types";

// 模拟指数行情数据
const INDEX_DATA = [
  { name: "上证指数", code: "SH000001", price: 3185.42, change: 27.36, changeRate: 0.87 },
  { name: "深成指数", code: "SZ399001", price: 10240.18, change: 124.52, changeRate: 1.23 },
  { name: "创业板指", code: "SZ399006", price: 2045.67, change: 31.92, changeRate: 1.59 },
  { name: "科创50", code: "SH000688", price: 876.34, change: -3.21, changeRate: -0.36 },
];

const FEATURES = [
  { icon: PieChart, title: "资产管理", desc: "全面掌握资产配置与收益", to: "/assets", color: "text-chart-1" },
  { icon: TrendingUp, title: "市场行情", desc: "实时行情，洞察市场机会", to: "/market", color: "text-chart-2" },
  { icon: Package, title: "投资产品", desc: "精选理财产品，稳健增值", to: "/products", color: "text-chart-3" },
  { icon: BarChart2, title: "财富规划", desc: "科学规划，实现财务自由", to: "/planning", color: "text-chart-4" },
  { icon: BookOpen, title: "资讯中心", desc: "权威财经资讯，专业分析", to: "/news", color: "text-chart-5" },
  { icon: Shield, title: "安全保障", desc: "银行级加密，资产安全无忧", to: "/", color: "text-gold" },
];

export default function HomePage() {
  const { user } = useAuth();
  const [articles, setArticles] = useState<Partial<Article>[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingArticles, setLoadingArticles] = useState(true);
  const [loadingProducts, setLoadingProducts] = useState(true);

  useEffect(() => {
    fetchArticles({ limit: 4 })
      .then(setArticles)
      .finally(() => setLoadingArticles(false));
    fetchProducts({ limit: 4 })
      .then(setProducts)
      .finally(() => setLoadingProducts(false));
  }, []);

  return (
    <div className="min-w-0">
      {/* Hero */}
      <section className="bg-primary px-6 py-12 md:py-16">
        <div className="max-w-5xl mx-auto">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 bg-primary-foreground/10 rounded-full px-3 py-1 mb-4">
              <Zap className="h-3.5 w-3.5 text-gold" />
              <span className="text-primary-foreground/80 text-xs">专业财富管理平台</span>
            </div>
            <h1 className="text-primary-foreground text-2xl md:text-4xl font-bold leading-tight text-balance mb-4">
              让每一分财富<br className="hidden md:block" />都在增值的轨道上
            </h1>
            <p className="text-primary-foreground/70 text-sm md:text-base leading-relaxed text-pretty mb-6 max-w-lg">
              集资产管理、市场行情、投资产品、财富规划于一体，为您提供全方位的个人财富管理解决方案。
            </p>
            <div className="flex flex-wrap gap-3">
              {user ? (
                <Link to="/assets">
                  <Button variant="default" size="lg">查看我的资产</Button>
                </Link>
              ) : (
                <Link to="/login">
                  <Button variant="default" size="lg">立即开始理财</Button>
                </Link>
              )}
              <Link to="/products">
                <Button variant="ghost" size="lg" className="border border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10">
                  浏览理财产品
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Market index ticker */}
      <section className="bg-card border-b border-border px-4 py-3">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-wrap gap-x-6 gap-y-2">
            {INDEX_DATA.map((idx) => (
              <div key={idx.code} className="flex items-center gap-2 min-w-0">
                <span className="text-sm font-medium text-foreground whitespace-nowrap">{idx.name}</span>
                <span className="font-number text-sm font-semibold whitespace-nowrap">{idx.price.toFixed(2)}</span>
                <span className={`text-xs font-number whitespace-nowrap ${riseOrFall(idx.changeRate)}`}>
                  {formatPercent(idx.changeRate)}
                </span>
              </div>
            ))}
            <Link to="/market" className="ml-auto flex items-center gap-1 text-xs text-primary hover:underline whitespace-nowrap shrink-0">
              更多行情 <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
        </div>
      </section>

      <div className="max-w-5xl mx-auto px-4 md:px-6 py-8 space-y-10">
        {/* Features grid */}
        <section>
          <h2 className="text-base font-semibold mb-4 text-balance">核心功能</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {FEATURES.map(({ icon: Icon, title, desc, to, color }) => (
              <Link key={title} to={to}>
                <Card className="h-full hover:shadow-md transition-shadow cursor-pointer group">
                  <CardContent className="p-4">
                    <div className={`w-9 h-9 rounded-lg bg-muted flex items-center justify-center mb-3 group-hover:scale-105 transition-transform`}>
                      <Icon className={`h-5 w-5 ${color}`} />
                    </div>
                    <div className="font-medium text-sm mb-1">{title}</div>
                    <div className="text-xs text-muted-foreground text-pretty">{desc}</div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Hot products */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-semibold text-balance">热门产品</h2>
              <Link to="/products" className="flex items-center gap-1 text-xs text-primary hover:underline">
                查看全部 <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            <div className="space-y-2">
              {loadingProducts ? (
                Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)
              ) : (
                products.map((p) => (
                  <Link key={p.id} to={`/products/${p.id}`}>
                    <Card className="hover:shadow-md transition-shadow cursor-pointer">
                      <CardContent className="p-3 flex items-center gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 min-w-0">
                            <span className="text-sm font-medium truncate">{p.name}</span>
                            <Badge className={`text-xs shrink-0 ${riskLevelColor(p.risk_level)}`} variant="outline">
                              {p.risk_level}
                            </Badge>
                          </div>
                          <div className="text-xs text-muted-foreground mt-0.5">{productTypeLabel(p.product_type)} · 起购 {formatCNY(p.min_purchase, 0)}</div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="font-number text-base font-bold text-rise">{p.annual_return.toFixed(2)}%</div>
                          <div className="text-xs text-muted-foreground">年化收益</div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))
              )}
            </div>
          </section>

          {/* Latest news */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-semibold text-balance">最新资讯</h2>
              <Link to="/news" className="flex items-center gap-1 text-xs text-primary hover:underline">
                查看全部 <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            <div className="space-y-2">
              {loadingArticles ? (
                Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)
              ) : (
                articles.map((a) => (
                  <Link key={a.id} to={`/news/${a.id}`}>
                    <Card className="hover:shadow-md transition-shadow cursor-pointer">
                      <CardContent className="p-3">
                        <div className="flex items-start gap-2 min-w-0">
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-medium line-clamp-2 text-balance">{a.title}</div>
                            <div className="flex items-center gap-2 mt-1.5">
                              <Badge variant="secondary" className="text-xs">{articleCategoryLabel(a.category ?? "news")}</Badge>
                              <span className="text-xs text-muted-foreground">{formatRelativeTime(a.published_at ?? a.created_at ?? "")}</span>
                            </div>
                          </div>
                          {a.category === "news" && <TrendingUp className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />}
                          {a.category === "analysis" && <BarChart2 className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />}
                          {a.category === "strategy" && <TrendingDown className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />}
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))
              )}
            </div>
          </section>
        </div>

        {/* CTA Banner */}
        {!user && (
          <Card className="bg-primary text-primary-foreground border-0">
            <CardContent className="p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <div className="font-bold text-base md:text-lg text-balance">立即注册，开启您的财富之旅</div>
                <div className="text-primary-foreground/70 text-sm mt-1 text-pretty">免费注册，专业工具助您实现财务目标</div>
              </div>
              <Link to="/login">
                <Button variant="default" className="shrink-0">免费注册</Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
