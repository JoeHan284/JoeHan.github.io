import { useState, useEffect } from "react";
import { Navigate } from "react-router-dom";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid } from "recharts";
import { TrendingUp, TrendingDown, RefreshCw } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { fetchAssets } from "@/api/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatCNY, formatPercent, riseOrFall, assetTypeLabel } from "@/lib/utils";
import type { Asset } from "@/types/types";

const ASSET_COLORS = ["hsl(214,55%,23%)", "hsl(43,63%,52%)", "hsl(161,100%,27%)", "hsl(16,100%,45%)"];

// 生成模拟收益走势数据
function genTrendData(days: number) {
  let base = 100000;
  return Array.from({ length: days }, (_, i) => {
    base += (Math.random() - 0.45) * 2000;
    const date = new Date();
    date.setDate(date.getDate() - (days - i - 1));
    return {
      date: `${date.getMonth() + 1}/${date.getDate()}`,
      value: Math.max(base, 80000),
    };
  });
}

// 模拟资产数据（登录用户无实际数据时展示）
const MOCK_ASSETS: Asset[] = [
  { id: "1", user_id: "", name: "贵州茅台", code: "600519", asset_type: "stock", quantity: 10, cost_price: 1680, current_price: 1780, market_value: 17800, profit_loss: 1000, profit_loss_rate: 5.95, created_at: "", updated_at: "" },
  { id: "2", user_id: "", name: "易方达蓝筹精选", code: "YFD003", asset_type: "fund", quantity: 5000, cost_price: 2.6, current_price: 2.876, market_value: 14380, profit_loss: 1380, profit_loss_rate: 10.62, created_at: "", updated_at: "" },
  { id: "3", user_id: "", name: "工银理财稳享180天", code: "GY004", asset_type: "bond", quantity: 1, cost_price: 20000, current_price: 20750, market_value: 20750, profit_loss: 750, profit_loss_rate: 3.75, created_at: "", updated_at: "" },
  { id: "4", user_id: "", name: "定期存款", code: null, asset_type: "deposit", quantity: 1, cost_price: 50000, current_price: 50000, market_value: 50000, profit_loss: 0, profit_loss_rate: 0, created_at: "", updated_at: "" },
];

export default function AssetsPage() {
  const { user, loading: authLoading } = useAuth();
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);
  const [trendDays, setTrendDays] = useState<7 | 30 | 90>(30);
  const [trendData] = useState(() => ({ 7: genTrendData(7), 30: genTrendData(30), 90: genTrendData(90) }));

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    fetchAssets(user.id)
      .then((data) => setAssets(data.length > 0 ? data : MOCK_ASSETS))
      .catch(() => setAssets(MOCK_ASSETS))
      .finally(() => setLoading(false));
  }, [user]);

  if (!authLoading && !user) return <Navigate to="/login" replace />;

  const totalValue = assets.reduce((s, a) => s + a.market_value, 0);
  const totalProfit = assets.reduce((s, a) => s + a.profit_loss, 0);
  const totalCost = totalValue - totalProfit;
  const totalProfitRate = totalCost > 0 ? (totalProfit / totalCost) * 100 : 0;

  // 资产配置饼图数据
  const pieData = ["stock", "fund", "bond", "deposit"].map((type) => ({
    name: assetTypeLabel(type),
    value: assets.filter((a) => a.asset_type === type).reduce((s, a) => s + a.market_value, 0),
  })).filter((d) => d.value > 0);

  const StatCard = ({ label, value, sub, subClass }: { label: string; value: string; sub?: string; subClass?: string }) => (
    <Card className="h-full">
      <CardContent className="p-4">
        <div className="text-xs text-muted-foreground mb-1">{label}</div>
        <div className="font-number text-xl font-bold">{value}</div>
        {sub && <div className={`text-xs mt-0.5 font-number ${subClass ?? "text-muted-foreground"}`}>{sub}</div>}
      </CardContent>
    </Card>
  );

  if (loading || authLoading) {
    return (
      <div className="p-4 md:p-6 space-y-4 max-w-5xl mx-auto">
        <Skeleton className="h-8 w-40" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-20" />)}
        </div>
        <Skeleton className="h-64" />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto min-w-0 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-balance">资产管理</h1>
          <p className="text-sm text-muted-foreground">总览您的投资组合与收益情况</p>
        </div>
        <button className="text-muted-foreground hover:text-foreground transition-colors">
          <RefreshCw className="h-4 w-4" />
        </button>
      </div>

      {/* 总览卡片 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="总资产" value={formatCNY(totalValue)} />
        <StatCard
          label="总收益"
          value={formatCNY(totalProfit)}
          sub={formatPercent(totalProfitRate)}
          subClass={riseOrFall(totalProfit)}
        />
        <StatCard label="持仓数量" value={`${assets.length} 只`} />
        <StatCard label="今日盈亏" value={formatCNY(totalProfit * 0.02)} sub="模拟数据" subClass={riseOrFall(1)} />
      </div>

      {/* 图表区 */}
      <div className="grid md:grid-cols-5 gap-4">
        {/* 收益走势 */}
        <Card className="md:col-span-3 h-full">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm">收益走势</CardTitle>
              <div className="flex gap-1">
                {([7, 30, 90] as const).map((d) => (
                  <button
                    key={d}
                    onClick={() => setTrendDays(d)}
                    className={`px-2 py-0.5 text-xs rounded transition-colors ${trendDays === d ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
                  >
                    {d}天
                  </button>
                ))}
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <div className="w-full min-w-0 overflow-hidden">
              <ResponsiveContainer width="100%" height={180}>
                <LineChart data={trendData[trendDays]} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} tickFormatter={(v) => `${(v / 10000).toFixed(0)}万`} />
                  <Tooltip formatter={(v: number) => [`¥${v.toFixed(0)}`, "资产价值"]} />
                  <Line type="monotone" dataKey="value" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* 资产配置饼图 */}
        <Card className="md:col-span-2 h-full">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">资产配置</CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <div className="w-full min-w-0 overflow-hidden">
              <ResponsiveContainer width="100%" height={130}>
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={35} outerRadius={55} dataKey="value" paddingAngle={2}>
                    {pieData.map((_, i) => (
                      <Cell key={i} fill={ASSET_COLORS[i % ASSET_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v: number) => [formatCNY(v), ""]} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-2 space-y-1">
              {pieData.map((d, i) => (
                <div key={d.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-sm shrink-0" style={{ background: ASSET_COLORS[i] }} />
                    <span className="text-muted-foreground">{d.name}</span>
                  </div>
                  <span className="font-number font-medium">{totalValue > 0 ? ((d.value / totalValue) * 100).toFixed(1) : "0"}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 持仓明细 */}
      <Tabs defaultValue="all">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold">持仓明细</h2>
          <TabsList>
            <TabsTrigger value="all" className="text-xs">全部</TabsTrigger>
            <TabsTrigger value="stock" className="text-xs">股票</TabsTrigger>
            <TabsTrigger value="fund" className="text-xs">基金</TabsTrigger>
            <TabsTrigger value="bond" className="text-xs">债券</TabsTrigger>
          </TabsList>
        </div>

        {(["all", "stock", "fund", "bond"] as const).map((tab) => (
          <TabsContent key={tab} value={tab}>
            <Card>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>名称</TableHead>
                      <TableHead className="text-right">市值</TableHead>
                      <TableHead className="text-right">收益</TableHead>
                      <TableHead className="text-right">收益率</TableHead>
                      <TableHead>类型</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {assets
                      .filter((a) => tab === "all" || a.asset_type === tab)
                      .map((a) => (
                        <TableRow key={a.id}>
                          <TableCell>
                            <div className="font-medium text-sm">{a.name}</div>
                            {a.code && <div className="text-xs text-muted-foreground">{a.code}</div>}
                          </TableCell>
                          <TableCell className="text-right font-number font-medium">{formatCNY(a.market_value)}</TableCell>
                          <TableCell className={`text-right font-number ${riseOrFall(a.profit_loss)}`}>
                            {a.profit_loss >= 0 ? "+" : ""}{formatCNY(a.profit_loss)}
                          </TableCell>
                          <TableCell className={`text-right font-number ${riseOrFall(a.profit_loss_rate)}`}>
                            <div className="flex items-center justify-end gap-1">
                              {a.profit_loss_rate > 0 ? <TrendingUp className="h-3 w-3" /> : a.profit_loss_rate < 0 ? <TrendingDown className="h-3 w-3" /> : null}
                              {formatPercent(a.profit_loss_rate)}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary" className="text-xs">{assetTypeLabel(a.asset_type)}</Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    {assets.filter((a) => tab === "all" || a.asset_type === tab).length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-muted-foreground py-8 text-sm">
                          暂无该类型资产
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
