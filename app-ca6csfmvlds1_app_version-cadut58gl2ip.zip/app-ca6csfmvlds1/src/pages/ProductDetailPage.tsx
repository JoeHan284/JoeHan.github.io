import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { ArrowLeft, TrendingUp, Shield, Building2, Calendar, BarChart2 } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { fetchProductById, fetchProductNavHistory } from "@/api/api";
import { formatCNY, productTypeLabel, riskLevelLabel, riskLevelColor, formatDate } from "@/lib/utils";
import type { Product, ProductNavHistory } from "@/types/types";
import { toast } from "sonner";

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [navHistory, setNavHistory] = useState<ProductNavHistory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    Promise.all([
      fetchProductById(id),
      fetchProductNavHistory(id, 60),
    ])
      .then(([p, nav]) => {
        setProduct(p);
        setNavHistory(nav);
      })
      .catch(() => toast.error("产品信息加载失败，请稍后重试"))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) {
    return (
      <div className="p-4 md:p-6 max-w-3xl mx-auto space-y-4">
        <Skeleton className="h-6 w-32" />
        <Skeleton className="h-32" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="p-4 md:p-6 max-w-3xl mx-auto text-center py-16">
        <div className="text-muted-foreground mb-4">产品不存在或已下架</div>
        <Button variant="outline" onClick={() => navigate("/products")}>返回产品列表</Button>
      </div>
    );
  }

  const INFO_ITEMS = [
    { icon: BarChart2, label: "产品类型", value: productTypeLabel(product.product_type) },
    { icon: Shield, label: "风险等级", value: riskLevelLabel(product.risk_level) },
    { icon: TrendingUp, label: "最新净值", value: product.nav.toFixed(4) },
    { icon: Building2, label: "基金公司", value: product.fund_company ?? "—" },
    { icon: Calendar, label: "成立日期", value: product.inception_date ? formatDate(product.inception_date) : "—" },
    { icon: BarChart2, label: "基金规模", value: product.total_assets ? formatCNY(product.total_assets, 0) : "—" },
  ];

  // 若没有实际净值历史，生成模拟数据展示
  const chartData = navHistory.length > 0
    ? navHistory.map((n) => ({ date: n.date.slice(5), nav: +n.nav.toFixed(4) }))
    : Array.from({ length: 30 }, (_, i) => {
        const d = new Date();
        d.setDate(d.getDate() - (29 - i));
        return { date: `${d.getMonth() + 1}/${d.getDate()}`, nav: +(product.nav + (Math.random() - 0.5) * 0.1).toFixed(4) };
      });

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto min-w-0 space-y-6">
      {/* Back */}
      <Link to="/products" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors">
        <ArrowLeft className="h-4 w-4" />返回产品列表
      </Link>

      {/* Header */}
      <Card>
        <CardContent className="p-4 md:p-6">
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <h1 className="text-lg font-bold text-balance">{product.name}</h1>
                <Badge className={riskLevelColor(product.risk_level)} variant="outline">
                  {product.risk_level}
                </Badge>
              </div>
              <div className="text-xs text-muted-foreground">基金代码：{product.code}</div>
            </div>
            <div className="text-right">
              <div className="font-number text-3xl font-bold text-rise">{product.annual_return.toFixed(2)}%</div>
              <div className="text-xs text-muted-foreground mt-0.5">近一年年化收益</div>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-4">
            {INFO_ITEMS.map(({ icon: Icon, label, value }) => (
              <div key={label} className="flex items-center gap-2">
                <div className="w-7 h-7 rounded bg-muted flex items-center justify-center shrink-0">
                  <Icon className="h-3.5 w-3.5 text-muted-foreground" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">{label}</div>
                  <div className="text-sm font-medium">{value}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex gap-2 mt-5">
            <Button className="flex-1" onClick={() => toast.info("购买功能正在建设中，敬请期待")}>
              立即购买
            </Button>
            <Button variant="outline" className="flex-1" onClick={() => toast.info("加入自选功能正在建设中")}>
              加入自选
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* 起购金额横幅 */}
      <div className="bg-muted rounded-md p-3 flex items-center justify-between flex-wrap gap-2">
        <div className="text-sm">
          <span className="text-muted-foreground">起购金额：</span>
          <span className="font-semibold">{formatCNY(product.min_purchase, 0)}</span>
        </div>
        <div className="text-sm text-muted-foreground">T+1 确认，T+2 到账</div>
      </div>

      {/* 净值走势 */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">净值走势（近60天）</CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          <div className="w-full min-w-0 overflow-hidden">
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={chartData} margin={{ top: 4, right: 8, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} interval={Math.floor(chartData.length / 6)} />
                <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} domain={["auto", "auto"]} tickFormatter={(v: number) => v.toFixed(2)} />
                <Tooltip formatter={(v: number) => [v.toFixed(4), "单位净值"]} />
                <Line type="monotone" dataKey="nav" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* 产品说明 */}
      {product.description && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">产品说明</CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <p className="text-sm text-muted-foreground leading-relaxed text-pretty">{product.description}</p>
          </CardContent>
        </Card>
      )}

      {/* 风险提示 */}
      <Card className="border-destructive/20 bg-destructive/5">
        <CardContent className="p-4">
          <div className="text-xs text-muted-foreground leading-relaxed">
            <span className="font-semibold text-destructive">风险提示：</span>
            基金有风险，投资需谨慎。本页面所展示的数据和信息仅供参考，不构成投资建议。过往业绩不代表未来收益。投资前请仔细阅读基金合同及相关法律文件。
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
