import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Eye, Calendar, User } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { fetchArticleById } from "@/api/api";
import { articleCategoryLabel, formatDate } from "@/lib/utils";
import type { Article } from "@/types/types";
import { toast } from "sonner";

export default function ArticleDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [article, setArticle] = useState<Article | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    fetchArticleById(id)
      .then(setArticle)
      .catch(() => toast.error("文章加载失败，请稍后重试"))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) {
    return (
      <div className="p-4 md:p-6 max-w-3xl mx-auto space-y-4">
        <Skeleton className="h-5 w-32" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-4 w-48" />
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (!article) {
    return (
      <div className="p-4 md:p-6 max-w-3xl mx-auto text-center py-16">
        <div className="text-muted-foreground mb-4">文章不存在或已删除</div>
        <button onClick={() => navigate("/news")} className="text-primary hover:underline text-sm">
          返回资讯中心
        </button>
      </div>
    );
  }

  // 将 Markdown 风格的内容转为带段落的 JSX
  const renderContent = (text: string) => {
    const lines = text.split("\n");
    const elements: React.ReactElement[] = [];
    let key = 0;

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) {
        key++;
        continue;
      }
      if (trimmed.startsWith("**") && trimmed.endsWith("**") && trimmed.length > 4) {
        elements.push(<h2 key={key} className="text-base font-bold mt-5 mb-2 text-foreground text-balance">{trimmed.slice(2, -2)}</h2>);
      } else if (/^\d+\.\s\*\*/.test(trimmed)) {
        const match = trimmed.match(/^(\d+\.\s)\*\*(.*?)\*\*(.*)$/);
        if (match) {
          elements.push(
            <p key={key} className="text-sm leading-relaxed text-foreground/90 mb-2">
              <span className="font-medium">{match[1]}<strong>{match[2]}</strong>{match[3]}</span>
            </p>
          );
        } else {
          elements.push(<p key={key} className="text-sm leading-relaxed text-foreground/90 mb-2">{trimmed}</p>);
        }
      } else if (trimmed.startsWith("- ")) {
        elements.push(
          <li key={key} className="text-sm leading-relaxed text-foreground/90 mb-1 ml-4 list-disc">{trimmed.slice(2)}</li>
        );
      } else {
        elements.push(<p key={key} className="text-sm leading-relaxed text-foreground/90 mb-3 text-pretty">{trimmed}</p>);
      }
      key++;
    }
    return elements;
  };

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto min-w-0 space-y-6">
      {/* Back */}
      <button
        onClick={() => navigate("/news")}
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowLeft className="h-4 w-4" />返回资讯中心
      </button>

      {/* Article */}
      <article>
        <div className="mb-4">
          <Badge variant="secondary" className="mb-3 text-xs">
            {articleCategoryLabel(article.category)}
          </Badge>
          <h1 className="text-xl md:text-2xl font-bold leading-snug text-balance mb-4">{article.title}</h1>

          <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground pb-4 border-b border-border">
            {article.author && (
              <div className="flex items-center gap-1">
                <User className="h-3.5 w-3.5" />{article.author}
              </div>
            )}
            <div className="flex items-center gap-1">
              <Calendar className="h-3.5 w-3.5" />
              {formatDate(article.published_at ?? article.created_at)}
            </div>
            <div className="flex items-center gap-1">
              <Eye className="h-3.5 w-3.5" />{article.view_count.toLocaleString()} 阅读
            </div>
          </div>
        </div>

        {article.summary && (
          <Card className="mb-6 bg-muted/60 border-muted">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground leading-relaxed text-pretty italic">摘要：{article.summary}</p>
            </CardContent>
          </Card>
        )}

        <div className="prose-like">
          {renderContent(article.content)}
        </div>
      </article>

      {/* Footer */}
      <Card className="bg-muted/40 border-muted">
        <CardContent className="p-4 text-xs text-muted-foreground leading-relaxed">
          <strong>免责声明：</strong>本文内容仅供参考，不构成投资建议。投资有风险，决策需谨慎。过往市场表现不代表未来投资收益，请在充分了解相关风险的基础上，根据自身风险承受能力做出投资决策。
        </CardContent>
      </Card>
    </div>
  );
}
