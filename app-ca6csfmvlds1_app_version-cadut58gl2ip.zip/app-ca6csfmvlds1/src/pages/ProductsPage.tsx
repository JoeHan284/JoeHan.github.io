import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Search, SlidersHorizontal, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { fetchProducts } from "@/api/api";
import { formatCNY, productTypeLabel, riskLevelLabel, riskLevelColor } from "@/lib/utils";
import type { Product } from "@/types/types";

const TYPE_OPTIONS = [
  { value: "all", label: "全部类型" },
  { value: "money_market", label: "货币基金" },
  { value: "bond_fund", label: "债券基金" },
  { value: "stock_fund", label: "股票基金" },
  { value: "fixed_income", label: "固收产品" },
];

const RISK_OPTIONS = [
  { value: "all", label: "全部风险" },
  { value: "R1", label: "R1 低风险" },
  { value: "R2", label: "R2 中低风险" },
  { value: "R3", label: "R3 中风险" },
  { value: "R4", label: "R4 中高风险" },
  { value: "R5", label: "R5 高风险" },
];

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [riskFilter, setRiskFilter] = useState("all");

  useEffect(() => {
    fetchProducts({ limit: 50 })
      .then(setProducts)
      .finally(() => setLoading(false));
  }, []);

  const filtered = products.filter((p) => {
    const matchSearch = !search || p.name.includes(search) || p.code.includes(search) || (p.fund_company ?? "").includes(search);
    const matchType = typeFilter === "all" || p.product_type === typeFilter;
    const matchRisk = riskFilter === "all" || p.risk_level === riskFilter;
    return matchSearch && matchType && matchRisk;
  });

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto min-w-0 space-y-6">
      <div>
        <h1 className="text-lg font-bold text-balance">投资产品</h1>
        <p className="text-sm text-muted-foreground">精选优质理财产品，助您稳健增值</p>
      </div>

      {/* 筛选区 */}
      <div className="flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="搜索产品名称、代码..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-36">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {TYPE_OPTIONS.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={riskFilter} onValueChange={setRiskFilter}>
          <SelectTrigger className="w-36">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {RISK_OPTIONS.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
          </SelectContent>
        </Select>
        {(typeFilter !== "all" || riskFilter !== "all" || search) && (
          <Button variant="ghost" size="sm" onClick={() => { setTypeFilter("all"); setRiskFilter("all"); setSearch(""); }} className="text-muted-foreground">
            <SlidersHorizontal className="h-3.5 w-3.5 mr-1" />清除筛选
          </Button>
        )}
      </div>

      {/* 结果计数 */}
      {!loading && (
        <div className="text-sm text-muted-foreground">
          共 <span className="text-foreground font-medium">{filtered.length}</span> 款产品
        </div>
      )}

      {/* 产品卡片列表 */}
      {loading ? (
        <div className="grid md:grid-cols-2 gap-3">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-28" />)}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <Search className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
            <div className="text-muted-foreground">未找到符合条件的产品</div>
            <Button variant="link" onClick={() => { setTypeFilter("all"); setRiskFilter("all"); setSearch(""); }} className="mt-2">
              清除筛选条件
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-3">
          {filtered.map((p) => (
            <Link key={p.id} to={`/products/${p.id}`}>
              <Card className="h-full hover:shadow-md transition-shadow cursor-pointer group">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="font-semibold text-sm">{p.name}</span>
                        <Badge className={`text-xs shrink-0 ${riskLevelColor(p.risk_level)}`} variant="outline">
                          {p.risk_level}
                        </Badge>
                      </div>
                      <div className="text-xs text-muted-foreground mb-2">
                        {p.fund_company ?? "—"} · {productTypeLabel(p.product_type)}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                        <span>起购 {formatCNY(p.min_purchase, 0)}</span>
                        <span>净值 {p.nav.toFixed(4)}</span>
                        {p.total_assets && (
                          <span>规模 {formatCNY(p.total_assets, 0)}</span>
                        )}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-number text-xl font-bold text-rise">{p.annual_return.toFixed(2)}%</div>
                      <div className="text-xs text-muted-foreground flex items-center gap-0.5 justify-end">
                        <TrendingUp className="h-3 w-3" />年化收益
                      </div>
                    </div>
                  </div>
                  {p.description && (
                    <p className="text-xs text-muted-foreground mt-2 line-clamp-2 text-pretty">{p.description}</p>
                  )}
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
