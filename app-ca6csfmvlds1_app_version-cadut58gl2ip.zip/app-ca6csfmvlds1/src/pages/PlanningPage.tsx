import { useState } from "react";
import { Calculator, Target, GraduationCap, TrendingUp, ChevronRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { formatCNY } from "@/lib/utils";

// ── 退休规划计算 ───────────────────────────────────────────
function calcRetirement(
  currentAge: number, retirementAge: number, monthlyExpense: number,
  lifeExpectancy: number, annualReturn: number, currentSavings: number
) {
  const yearsToRetire = retirementAge - currentAge;
  const yearsInRetirement = lifeExpectancy - retirementAge;
  const monthlyReturn = annualReturn / 100 / 12;
  // 退休总需求（年金现值）
  const totalNeeded = monthlyExpense * (1 - Math.pow(1 + monthlyReturn, -yearsInRetirement * 12)) / monthlyReturn;
  // 当前储蓄终值
  const savingsFV = currentSavings * Math.pow(1 + annualReturn / 100, yearsToRetire);
  const gap = Math.max(totalNeeded - savingsFV, 0);
  // 所需月储蓄（年金终值反算）
  const monthlyNeeded = gap > 0
    ? gap * monthlyReturn / (Math.pow(1 + monthlyReturn, yearsToRetire * 12) - 1)
    : 0;
  return { totalNeeded, savingsFV, gap, monthlyNeeded };
}

// ── 教育金规划计算 ────────────────────────────────────────
function calcEducation(
  childAge: number, educationStartAge: number,
  annualCost: number, years: number, annualReturn: number, currentSavings: number
) {
  const yearsToStart = Math.max(educationStartAge - childAge, 0);
  const monthlyReturn = annualReturn / 100 / 12;
  // 教育总费用（按年金现值，在入学时所需）
  const totalAtStart = annualCost * (1 - Math.pow(1 + annualReturn / 100, -years)) / (annualReturn / 100);
  const savingsFV = currentSavings * Math.pow(1 + annualReturn / 100, yearsToStart);
  const gap = Math.max(totalAtStart - savingsFV, 0);
  const monthlyNeeded = gap > 0 && yearsToStart > 0
    ? gap * monthlyReturn / (Math.pow(1 + monthlyReturn, yearsToStart * 12) - 1)
    : 0;
  return { totalAtStart, savingsFV, gap, monthlyNeeded };
}

// ── 理财目标计算 ──────────────────────────────────────────
function calcGoal(
  targetAmount: number, years: number, annualReturn: number, currentSavings: number
) {
  const monthlyReturn = annualReturn / 100 / 12;
  const savingsFV = currentSavings * Math.pow(1 + annualReturn / 100, years);
  const gap = Math.max(targetAmount - savingsFV, 0);
  const monthlyNeeded = gap > 0
    ? gap * monthlyReturn / (Math.pow(1 + monthlyReturn, years * 12) - 1)
    : 0;
  const progressPct = Math.min((savingsFV / targetAmount) * 100, 100);
  return { savingsFV, gap, monthlyNeeded, progressPct };
}

const NumInput = ({ id, label, value, onChange, min, max, step = 1, suffix }: {
  id: string; label: string; value: number;
  onChange: (v: number) => void;
  min?: number; max?: number; step?: number; suffix?: string;
}) => (
  <div className="space-y-1.5">
    <Label htmlFor={id}>{label}</Label>
    <div className="relative">
      <Input
        id={id} type="number" min={min} max={max} step={step}
        value={value}
        onChange={(e) => onChange(Math.max(min ?? 0, Number(e.target.value)))}
      />
      {suffix && <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">{suffix}</span>}
    </div>
  </div>
);

export default function PlanningPage() {
  // 退休规划
  const [ret, setRet] = useState({ currentAge: 30, retirementAge: 60, monthlyExpense: 10000, lifeExpectancy: 85, annualReturn: 6, currentSavings: 100000 });
  const [retResult, setRetResult] = useState<ReturnType<typeof calcRetirement> | null>(null);

  // 教育金
  const [edu, setEdu] = useState({ childAge: 5, educationStartAge: 18, annualCost: 50000, years: 4, annualReturn: 5, currentSavings: 30000 });
  const [eduResult, setEduResult] = useState<ReturnType<typeof calcEducation> | null>(null);

  // 理财目标
  const [goal, setGoal] = useState({ targetAmount: 1000000, years: 10, annualReturn: 7, currentSavings: 100000 });
  const [goalResult, setGoalResult] = useState<ReturnType<typeof calcGoal> | null>(null);

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto min-w-0 space-y-6">
      <div>
        <h1 className="text-lg font-bold text-balance">财富规划</h1>
        <p className="text-sm text-muted-foreground">科学规划您的财务目标，量化实现路径</p>
      </div>

      <Tabs defaultValue="retirement">
        <TabsList className="w-full">
          <TabsTrigger value="retirement" className="flex-1 text-xs">
            <Calculator className="h-3.5 w-3.5 mr-1 hidden md:inline" />退休规划
          </TabsTrigger>
          <TabsTrigger value="education" className="flex-1 text-xs">
            <GraduationCap className="h-3.5 w-3.5 mr-1 hidden md:inline" />教育金
          </TabsTrigger>
          <TabsTrigger value="goal" className="flex-1 text-xs">
            <Target className="h-3.5 w-3.5 mr-1 hidden md:inline" />理财目标
          </TabsTrigger>
        </TabsList>

        {/* 退休规划 */}
        <TabsContent value="retirement" className="mt-4 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Calculator className="h-4 w-4 text-primary" />退休规划计算器
              </CardTitle>
              <CardDescription>填入您的基本信息，计算退休所需储蓄</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <NumInput id="cur-age" label="当前年龄" value={ret.currentAge} onChange={(v) => setRet({ ...ret, currentAge: v })} min={18} max={80} suffix="岁" />
                <NumInput id="ret-age" label="计划退休年龄" value={ret.retirementAge} onChange={(v) => setRet({ ...ret, retirementAge: v })} min={ret.currentAge + 1} max={80} suffix="岁" />
                <NumInput id="monthly-exp" label="预期月生活支出" value={ret.monthlyExpense} onChange={(v) => setRet({ ...ret, monthlyExpense: v })} min={1000} step={500} suffix="元" />
                <NumInput id="life-exp" label="预期寿命" value={ret.lifeExpectancy} onChange={(v) => setRet({ ...ret, lifeExpectancy: v })} min={ret.retirementAge + 1} max={120} suffix="岁" />
                <NumInput id="ret-return" label="预期年化收益率" value={ret.annualReturn} onChange={(v) => setRet({ ...ret, annualReturn: v })} min={0} max={30} step={0.5} suffix="%" />
                <NumInput id="cur-savings" label="已有储蓄" value={ret.currentSavings} onChange={(v) => setRet({ ...ret, currentSavings: v })} min={0} step={10000} suffix="元" />
              </div>
              <Button className="w-full" onClick={() => setRetResult(calcRetirement(ret.currentAge, ret.retirementAge, ret.monthlyExpense, ret.lifeExpectancy, ret.annualReturn, ret.currentSavings))}>
                开始计算 <ChevronRight className="h-4 w-4" />
              </Button>
            </CardContent>
          </Card>

          {retResult && (
            <Card className="border-primary/20 bg-primary/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-primary">计算结果</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <ResultItem label="退休所需总资金" value={formatCNY(retResult.totalNeeded)} highlight />
                  <ResultItem label="现有储蓄未来价值" value={formatCNY(retResult.savingsFV)} />
                  <ResultItem label="资金缺口" value={formatCNY(retResult.gap)} warn={retResult.gap > 0} />
                  <ResultItem label="建议每月储蓄" value={formatCNY(retResult.monthlyNeeded)} highlight={retResult.monthlyNeeded > 0} />
                </div>
                {retResult.gap === 0 && (
                  <div className="text-xs text-fall font-medium bg-fall/10 rounded p-2 text-center">
                    您的现有储蓄已足够支撑退休生活，无需额外储蓄！
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* 教育金规划 */}
        <TabsContent value="education" className="mt-4 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <GraduationCap className="h-4 w-4 text-primary" />教育金规划计算器
              </CardTitle>
              <CardDescription>为子女教育提前储备资金</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <NumInput id="child-age" label="子女当前年龄" value={edu.childAge} onChange={(v) => setEdu({ ...edu, childAge: v })} min={0} max={17} suffix="岁" />
                <NumInput id="edu-start" label="开始上学年龄" value={edu.educationStartAge} onChange={(v) => setEdu({ ...edu, educationStartAge: v })} min={edu.childAge + 1} max={25} suffix="岁" />
                <NumInput id="annual-cost" label="年均教育费用" value={edu.annualCost} onChange={(v) => setEdu({ ...edu, annualCost: v })} min={1000} step={5000} suffix="元" />
                <NumInput id="edu-years" label="教育年限" value={edu.years} onChange={(v) => setEdu({ ...edu, years: v })} min={1} max={10} suffix="年" />
                <NumInput id="edu-return" label="预期年化收益率" value={edu.annualReturn} onChange={(v) => setEdu({ ...edu, annualReturn: v })} min={0} max={30} step={0.5} suffix="%" />
                <NumInput id="edu-savings" label="已有教育储蓄" value={edu.currentSavings} onChange={(v) => setEdu({ ...edu, currentSavings: v })} min={0} step={5000} suffix="元" />
              </div>
              <Button className="w-full" onClick={() => setEduResult(calcEducation(edu.childAge, edu.educationStartAge, edu.annualCost, edu.years, edu.annualReturn, edu.currentSavings))}>
                开始计算 <ChevronRight className="h-4 w-4" />
              </Button>
            </CardContent>
          </Card>

          {eduResult && (
            <Card className="border-primary/20 bg-primary/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-primary">计算结果</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <ResultItem label="入学时所需总资金" value={formatCNY(eduResult.totalAtStart)} highlight />
                  <ResultItem label="现有储蓄未来价值" value={formatCNY(eduResult.savingsFV)} />
                  <ResultItem label="资金缺口" value={formatCNY(eduResult.gap)} warn={eduResult.gap > 0} />
                  <ResultItem label="建议每月储蓄" value={formatCNY(eduResult.monthlyNeeded)} highlight={eduResult.monthlyNeeded > 0} />
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* 理财目标 */}
        <TabsContent value="goal" className="mt-4 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Target className="h-4 w-4 text-primary" />理财目标规划
              </CardTitle>
              <CardDescription>设置您的财富目标，制定储蓄方案</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <NumInput id="target" label="目标金额" value={goal.targetAmount} onChange={(v) => setGoal({ ...goal, targetAmount: v })} min={10000} step={10000} suffix="元" />
                <NumInput id="goal-years" label="达成年限" value={goal.years} onChange={(v) => setGoal({ ...goal, years: v })} min={1} max={50} suffix="年" />
                <NumInput id="goal-return" label="预期年化收益率" value={goal.annualReturn} onChange={(v) => setGoal({ ...goal, annualReturn: v })} min={0} max={30} step={0.5} suffix="%" />
                <NumInput id="goal-savings" label="初始本金" value={goal.currentSavings} onChange={(v) => setGoal({ ...goal, currentSavings: v })} min={0} step={10000} suffix="元" />
              </div>
              <Button className="w-full" onClick={() => setGoalResult(calcGoal(goal.targetAmount, goal.years, goal.annualReturn, goal.currentSavings))}>
                生成方案 <ChevronRight className="h-4 w-4" />
              </Button>
            </CardContent>
          </Card>

          {goalResult && (
            <Card className="border-primary/20 bg-primary/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-primary">规划方案</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-muted-foreground">目标达成进度（仅凭初始本金）</span>
                    <span className="font-number font-semibold">{goalResult.progressPct.toFixed(1)}%</span>
                  </div>
                  <Progress value={goalResult.progressPct} className="h-2" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <ResultItem label="目标金额" value={formatCNY(goal.targetAmount)} />
                  <ResultItem label="本金未来价值" value={formatCNY(goalResult.savingsFV)} />
                  <ResultItem label="资金缺口" value={formatCNY(goalResult.gap)} warn={goalResult.gap > 0} />
                  <ResultItem label="建议每月储蓄" value={formatCNY(goalResult.monthlyNeeded)} highlight={goalResult.monthlyNeeded > 0} />
                </div>
                {goalResult.gap === 0 && (
                  <div className="text-xs text-fall font-medium bg-fall/10 rounded p-2 text-center">
                    仅靠初始本金即可达成目标，无需额外储蓄！
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* 说明卡片 */}
      <Card>
        <CardContent className="p-4">
          <div className="flex gap-3">
            <TrendingUp className="h-4 w-4 text-gold shrink-0 mt-0.5" />
            <div className="text-xs text-muted-foreground leading-relaxed text-pretty">
              以上计算结果仅供参考，基于复利模型估算，未考虑通货膨胀、税收等因素。实际投资收益存在不确定性，建议咨询专业理财顾问制定个性化方案。
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function ResultItem({ label, value, highlight, warn }: { label: string; value: string; highlight?: boolean; warn?: boolean }) {
  return (
    <div className="bg-background rounded-md p-3 border border-border">
      <div className="text-xs text-muted-foreground mb-1">{label}</div>
      <div className={`font-number font-bold text-base ${highlight ? "text-primary" : warn ? "text-rise" : "text-foreground"}`}>
        {value}
      </div>
    </div>
  );
}
