import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Search, Eye, TrendingUp, BarChart2, BookOpen } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { fetchArticles } from "@/api/api";
import { articleCategoryLabel, formatRelativeTime } from "@/lib/utils";
import type { Article } from "@/types/types";

const CATEGORY_ICONS: Record<string, React.ElementType> = {
  news: TrendingUp,
  analysis: BarChart2,
  strategy: BookOpen,
};

function ArticleCard({ article }: { article: Partial<Article> }) {
  const Icon = CATEGORY_ICONS[article.category ?? "news"] ?? TrendingUp;
  return (
    <Link to={`/news/${article.id}`}>
      <Card className="h-full hover:shadow-md transition-shadow cursor-pointer group">
        <CardContent className="p-4">
          <div className="flex items-start gap-3 min-w-0">
            <div className="w-9 h-9 rounded-lg bg-muted flex items-center justify-center shrink-0 group-hover:bg-primary/10 transition-colors">
              <Icon className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-semibold line-clamp-2 leading-snug text-balance mb-1.5 group-hover:text-primary transition-colors">
                {article.title}
              </h3>
              {article.summary && (
                <p className="text-xs text-muted-foreground line-clamp-2 text-pretty mb-2">{article.summary}</p>
              )}
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant="secondary" className="text-xs">
                  {articleCategoryLabel(article.category ?? "news")}
                </Badge>
                {article.author && (
                  <span className="text-xs text-muted-foreground">{article.author}</span>
                )}
                <span className="text-xs text-muted-foreground ml-auto">
                  {formatRelativeTime(article.published_at ?? article.created_at ?? "")}
                </span>
                {article.view_count !== undefined && (
                  <span className="flex items-center gap-0.5 text-xs text-muted-foreground">
                    <Eye className="h-3 w-3" />{article.view_count.toLocaleString()}
                  </span>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

export default function NewsPage() {
  const [articles, setArticles] = useState<Partial<Article>[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetchArticles({ limit: 30 })
      .then(setArticles)
      .finally(() => setLoading(false));
  }, []);

  const filtered = articles.filter(
    (a) => !search || (a.title ?? "").includes(search) || (a.summary ?? "").includes(search)
  );

  const byCategory = (cat: string) =>
    cat === "all" ? filtered : filtered.filter((a) => a.category === cat);

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto min-w-0 space-y-6">
      <div>
        <h1 className="text-lg font-bold text-balance">资讯中心</h1>
        <p className="text-sm text-muted-foreground">权威财经资讯，专业市场分析</p>
      </div>

      {/* 搜索 */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="搜索资讯标题、关键词..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-24" />)}
        </div>
      ) : (
        <Tabs defaultValue="all">
          <TabsList className="w-full md:w-auto">
            <TabsTrigger value="all" className="text-xs">全部</TabsTrigger>
            <TabsTrigger value="news" className="text-xs">财经新闻</TabsTrigger>
            <TabsTrigger value="analysis" className="text-xs">市场分析</TabsTrigger>
            <TabsTrigger value="strategy" className="text-xs">投资策略</TabsTrigger>
          </TabsList>

          {(["all", "news", "analysis", "strategy"] as const).map((cat) => (
            <TabsContent key={cat} value={cat} className="mt-4">
              {byCategory(cat).length === 0 ? (
                <Card>
                  <CardContent className="py-16 text-center">
                    <BookOpen className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                    <div className="text-muted-foreground text-sm">暂无相关资讯</div>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-3">
                  {byCategory(cat).map((a) => (
                    <ArticleCard key={a.id} article={a} />
                  ))}
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      )}
    </div>
  );
}
