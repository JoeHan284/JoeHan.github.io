import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff, TrendingUp, Shield, BarChart2 } from "lucide-react";
import { supabase } from "@/db/supabase";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";

const features = [
  { icon: TrendingUp, title: "专业行情", desc: "实时掌握沪深市场动态" },
  { icon: BarChart2, title: "资产管理", desc: "全方位管理您的投资组合" },
  { icon: Shield, title: "安全保障", desc: "银行级别数据加密保护" },
];

export default function LoginPage() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<"login" | "register">("login");
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);

  // Login form
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPwd, setLoginPwd] = useState("");

  // Register form
  const [regEmail, setRegEmail] = useState("");
  const [regPwd, setRegPwd] = useState("");
  const [regConfirm, setRegConfirm] = useState("");
  const [regUsername, setRegUsername] = useState("");

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    if (!loginEmail || !loginPwd) { toast.error("请填写邮箱和密码"); return; }
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email: loginEmail, password: loginPwd });
    setLoading(false);
    if (error) { toast.error(error.message.includes("Invalid") ? "邮箱或密码错误，请重新输入" : error.message); return; }
    toast.success("登录成功，欢迎回来！");
    navigate("/");
  }

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    if (!regEmail || !regPwd || !regConfirm) { toast.error("请填写所有必填项"); return; }
    if (regPwd.length < 8) { toast.error("密码长度不能少于8位"); return; }
    if (regPwd !== regConfirm) { toast.error("两次输入的密码不一致"); return; }
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email: regEmail,
      password: regPwd,
      options: { data: { username: regUsername || regEmail.split("@")[0] } },
    });
    setLoading(false);
    if (error) {
      toast.error(error.message.includes("already") ? "该邮箱已注册，请直接登录" : error.message);
      return;
    }
    // Update username in profile
    const { data: { user } } = await supabase.auth.getUser();
    if (user && regUsername) {
      await supabase.from("profiles").update({ username: regUsername }).eq("id", user.id);
    }
    toast.success("注册成功，欢迎加入中华理财网！");
    navigate("/");
  }

  return (
    <div className="min-h-screen flex">
      {/* Left branding panel */}
      <div className="hidden lg:flex flex-col justify-between w-[45%] bg-primary px-12 py-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gold flex items-center justify-center">
            <span className="text-gold-foreground font-bold text-lg">财</span>
          </div>
          <div>
            <div className="text-primary-foreground font-bold text-lg leading-tight">中华理财网</div>
            <div className="text-primary-foreground/60 text-xs">财富管理平台</div>
          </div>
        </div>

        <div>
          <h1 className="text-primary-foreground text-3xl font-bold leading-snug text-balance mb-3">
            专业的个人财富<br />管理解决方案
          </h1>
          <p className="text-primary-foreground/70 text-sm leading-relaxed text-pretty max-w-xs">
            集资产管理、市场行情、投资产品、财富规划于一体，助您实现财富稳健增值。
          </p>

          <div className="mt-10 space-y-4">
            {features.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-primary-foreground/10 flex items-center justify-center shrink-0">
                  <Icon className="h-5 w-5 text-gold" />
                </div>
                <div>
                  <div className="text-primary-foreground font-medium text-sm">{title}</div>
                  <div className="text-primary-foreground/60 text-xs">{desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <p className="text-primary-foreground/40 text-xs">© 2024 中华理财网 版权所有</p>
      </div>

      {/* Right auth panel */}
      <div className="flex-1 flex items-center justify-center p-6 bg-background">
        <div className="w-full max-w-sm">
          {/* Mobile logo */}
          <div className="flex items-center gap-2 mb-6 lg:hidden">
            <div className="w-8 h-8 rounded bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">财</span>
            </div>
            <span className="font-bold text-base">中华理财网</span>
          </div>

          <Card className="border-border">
            <CardHeader className="pb-4">
              <CardTitle className="text-xl">账户登录</CardTitle>
              <CardDescription>登录或注册以使用全部功能</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={tab} onValueChange={(v) => setTab(v as "login" | "register")}>
                <TabsList className="w-full mb-6">
                  <TabsTrigger value="login" className="flex-1">登录</TabsTrigger>
                  <TabsTrigger value="register" className="flex-1">注册</TabsTrigger>
                </TabsList>

                {/* Login */}
                <TabsContent value="login">
                  <form onSubmit={handleLogin} className="space-y-4">
                    <div className="space-y-1.5">
                      <Label htmlFor="login-email">邮箱地址</Label>
                      <Input
                        id="login-email"
                        type="email"
                        placeholder="请输入邮箱"
                        value={loginEmail}
                        onChange={e => setLoginEmail(e.target.value)}
                        autoComplete="email"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="login-pwd">密码</Label>
                      <div className="relative">
                        <Input
                          id="login-pwd"
                          type={showPwd ? "text" : "password"}
                          placeholder="请输入密码"
                          value={loginPwd}
                          onChange={e => setLoginPwd(e.target.value)}
                          className="pr-10"
                          autoComplete="current-password"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPwd(!showPwd)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        >
                          {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>
                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading ? "登录中..." : "登录"}
                    </Button>
                  </form>
                  <p className="mt-4 text-center text-sm text-muted-foreground">
                    还没有账号？{" "}
                    <button onClick={() => setTab("register")} className="text-primary hover:underline font-medium">
                      立即注册
                    </button>
                  </p>
                </TabsContent>

                {/* Register */}
                <TabsContent value="register">
                  <form onSubmit={handleRegister} className="space-y-4">
                    <div className="space-y-1.5">
                      <Label htmlFor="reg-username">用户名 <span className="text-muted-foreground font-normal">(选填)</span></Label>
                      <Input
                        id="reg-username"
                        placeholder="请输入用户名"
                        value={regUsername}
                        onChange={e => setRegUsername(e.target.value)}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="reg-email">邮箱地址 <span className="text-destructive">*</span></Label>
                      <Input
                        id="reg-email"
                        type="email"
                        placeholder="请输入邮箱"
                        value={regEmail}
                        onChange={e => setRegEmail(e.target.value)}
                        autoComplete="email"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="reg-pwd">密码 <span className="text-destructive">*</span></Label>
                      <div className="relative">
                        <Input
                          id="reg-pwd"
                          type={showPwd ? "text" : "password"}
                          placeholder="至少8位字符"
                          value={regPwd}
                          onChange={e => setRegPwd(e.target.value)}
                          className="pr-10"
                          autoComplete="new-password"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPwd(!showPwd)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        >
                          {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="reg-confirm">确认密码 <span className="text-destructive">*</span></Label>
                      <Input
                        id="reg-confirm"
                        type={showPwd ? "text" : "password"}
                        placeholder="再次输入密码"
                        value={regConfirm}
                        onChange={e => setRegConfirm(e.target.value)}
                        autoComplete="new-password"
                      />
                    </div>
                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading ? "注册中..." : "注册"}
                    </Button>
                  </form>
                  <p className="mt-4 text-center text-sm text-muted-foreground">
                    已有账号？{" "}
                    <button onClick={() => setTab("login")} className="text-primary hover:underline font-medium">
                      立即登录
                    </button>
                  </p>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <p className="mt-6 text-center text-xs text-muted-foreground">
            继续即表示您同意我们的{" "}
            <Link to="/" className="hover:underline text-primary">服务条款</Link>
            {" "}和{" "}
            <Link to="/" className="hover:underline text-primary">隐私政策</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
