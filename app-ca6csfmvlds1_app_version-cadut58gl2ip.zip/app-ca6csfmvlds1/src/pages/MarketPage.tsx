import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { TrendingUp, TrendingDown, RefreshCw, Search } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatPercent, riseOrFall } from "@/lib/utils";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// ── 模拟数据 ───────────────────────────────────────────────
const INDICES = [
  { name: "上证指数", code: "000001", price: 3185.42, change: 27.36, changeRate: 0.87, volume: "9865亿" },
  { name: "深成指数", code: "399001", price: 10240.18, change: 124.52, changeRate: 1.23, volume: "7432亿" },
  { name: "创业板指", code: "399006", price: 2045.67, change: 31.92, changeRate: 1.59, volume: "3021亿" },
  { name: "科创50", code: "000688", price: 876.34, change: -3.21, changeRate: -0.36, volume: "1234亿" },
  { name: "沪深300", code: "000300", price: 3845.62, change: 28.45, changeRate: 0.74, volume: "5678亿" },
  { name: "中证500", code: "000905", price: 5234.18, change: 72.13, changeRate: 1.40, volume: "2345亿" },
];

const STOCKS = [
  { name: "贵州茅台", code: "600519", price: 1780.00, changeRate: 2.10, volume: "28.4亿", sector: "白酒" },
  { name: "宁德时代", code: "300750", price: 198.50, changeRate: 3.24, volume: "56.8亿", sector: "新能源" },
  { name: "中国平安", code: "601318", price: 43.20, changeRate: -1.15, volume: "38.2亿", sector: "保险" },
  { name: "招商银行", code: "600036", price: 38.46, changeRate: 0.89, volume: "42.1亿", sector: "银行" },
  { name: "比亚迪", code: "002594", price: 238.60, changeRate: 4.12, volume: "78.3亿", sector: "汽车" },
  { name: "中芯国际", code: "688981", price: 68.30, changeRate: 5.32, volume: "34.5亿", sector: "半导体" },
  { name: "美的集团", code: "000333", price: 58.24, changeRate: -0.68, volume: "29.7亿", sector: "家电" },
  { name: "万科A", code: "000002", price: 7.85, changeRate: -2.48, volume: "52.4亿", sector: "房地产" },
  { name: "隆基绿能", code: "601012", price: 22.34, changeRate: 1.87, volume: "31.2亿", sector: "光伏" },
  { name: "东方财富", code: "300059", price: 15.62, changeRate: 2.45, volume: "89.6亿", sector: "互联网金融" },
  { name: "中国建筑", code: "601668", price: 5.68, changeRate: 0.35, volume: "18.4亿", sector: "建筑" },
  { name: "恒瑞医药", code: "600276", price: 32.15, changeRate: -1.82, volume: "14.6亿", sector: "医药" },
  { name: "三一重工", code: "600031", price: 15.46, changeRate: 0.92, volume: "22.3亿", sector: "工程机械" },
  { name: "工商银行", code: "601398", price: 5.92, changeRate: 0.51, volume: "41.2亿", sector: "银行" },
  { name: "迈瑞医疗", code: "300760", price: 248.60, changeRate: 1.34, volume: "8.7亿", sector: "医疗器械" },
];

const FUNDS = [
  { name: "易方达蓝筹精选", code: "005827", nav: 2.8760, changeRate: 1.24, type: "混合型" },
  { name: "天弘余额宝", code: "000198", nav: 1.0000, changeRate: 0.01, type: "货币型" },
  { name: "富国天惠成长", code: "161005", nav: 3.4560, changeRate: 0.89, type: "混合型" },
  { name: "广发科技先锋", code: "004744", nav: 4.8900, changeRate: 2.15, type: "股票型" },
  { name: "博时安心收益", code: "050021", nav: 1.5670, changeRate: 0.12, type: "债券型" },
  { name: "景顺长城新兴成长", code: "260108", nav: 3.1240, changeRate: 1.56, type: "混合型" },
  { name: "华夏成长混合", code: "000001", nav: 1.8920, changeRate: 0.78, type: "混合型" },
  { name: "南方稳利债券", code: "202101", nav: 1.2340, changeRate: 0.08, type: "债券型" },
];

// 板块涨跌幅柱状图数据
const SECTOR_DATA = [
  { name: "半导体", change: 3.24 },
  { name: "新能源", change: 2.85 },
  { name: "白酒", change: 2.15 },
  { name: "汽车", change: 1.92 },
  { name: "医疗", change: 0.87 },
  { name: "银行", change: 0.56 },
  { name: "家电", change: -0.45 },
  { name: "房地产", change: -2.12 },
].sort((a, b) => b.change - a.change);

export default function MarketPage() {
  const [search, setSearch] = useState("");
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const handleRefresh = () => {
    setLastRefresh(new Date());
    toast.success("行情数据已更新");
  };

  const filteredStocks = STOCKS.filter(
    (s) => s.name.includes(search) || s.code.includes(search) || s.sector.includes(search)
  );

  const riseCount = STOCKS.filter((s) => s.changeRate > 0).length;
  const fallCount = STOCKS.filter((s) => s.changeRate < 0).length;

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto min-w-0 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-balance">市场行情</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            数据更新：{lastRefresh.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })}
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={handleRefresh} className="gap-1.5">
          <RefreshCw className="h-3.5 w-3.5" />
          <span className="hidden md:inline">刷新</span>
        </Button>
      </div>

      {/* 指数概览 */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {INDICES.map((idx) => (
          <Card key={idx.code} className="h-full">
            <CardContent className="p-3 md:p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="text-xs text-muted-foreground">{idx.name}</div>
                  <div className="font-number text-lg md:text-xl font-bold mt-0.5">{idx.price.toLocaleString()}</div>
                  <div className={`flex items-center gap-1 text-xs font-number mt-0.5 ${riseOrFall(idx.changeRate)}`}>
                    {idx.changeRate > 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                    {idx.change >= 0 ? "+" : ""}{idx.change.toFixed(2)} ({formatPercent(idx.changeRate)})
                  </div>
                </div>
                <div className={`shrink-0 rounded px-1.5 py-0.5 text-xs font-medium ${idx.changeRate >= 0 ? "bg-rise/10 text-rise" : "bg-fall/10 text-fall"}`}>
                  {idx.changeRate >= 0 ? "涨" : "跌"}
                </div>
              </div>
              <div className="text-xs text-muted-foreground mt-1.5">成交 {idx.volume}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 涨跌家数统计 */}
      <Card>
        <CardContent className="p-4 flex items-center gap-4 flex-wrap">
          <div className="text-sm text-muted-foreground">今日市场</div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-sm bg-rise" />
            <span className="text-sm">上涨 <strong className="text-rise font-number">{riseCount}</strong> 只</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-sm bg-fall" />
            <span className="text-sm">下跌 <strong className="text-fall font-number">{fallCount}</strong> 只</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-sm bg-muted-foreground" />
            <span className="text-sm">平盘 <strong className="font-number">{STOCKS.length - riseCount - fallCount}</strong> 只</span>
          </div>
        </CardContent>
      </Card>

      {/* 板块热图 */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">板块涨跌幅</CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          <div className="w-full min-w-0 overflow-hidden">
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={SECTOR_DATA} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} tickFormatter={(v) => `${v}%`} />
                <Tooltip formatter={(v: number) => [`${v.toFixed(2)}%`, "涨跌幅"]} />
                <Bar dataKey="change" radius={[3, 3, 0, 0]}
                  fill="hsl(var(--rise))"
                  label={false}>
                  {SECTOR_DATA.map((entry, i) => (
                    <rect key={i} fill={entry.change >= 0 ? "hsl(var(--rise))" : "hsl(var(--fall))"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* 股票/基金行情详细 */}
      <Tabs defaultValue="stock">
        <div className="flex items-center justify-between gap-3 mb-3 flex-wrap">
          <TabsList>
            <TabsTrigger value="stock" className="text-xs">A股行情</TabsTrigger>
            <TabsTrigger value="fund" className="text-xs">基金净值</TabsTrigger>
            <TabsTrigger value="rise" className="text-xs">涨幅榜</TabsTrigger>
            <TabsTrigger value="fall" className="text-xs">跌幅榜</TabsTrigger>
          </TabsList>
          <div className="relative min-w-0 w-48">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              placeholder="搜索股票..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-8 h-8 text-xs"
            />
          </div>
        </div>

        {/* A股行情 */}
        <TabsContent value="stock">
          <Card>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>名称/代码</TableHead>
                    <TableHead className="text-right">最新价</TableHead>
                    <TableHead className="text-right">涨跌幅</TableHead>
                    <TableHead>板块</TableHead>
                    <TableHead className="text-right hidden md:table-cell">成交额</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStocks.map((s) => (
                    <TableRow key={s.code}>
                      <TableCell>
                        <div className="font-medium text-sm">{s.name}</div>
                        <div className="text-xs text-muted-foreground">{s.code}</div>
                      </TableCell>
                      <TableCell className="text-right font-number font-semibold">{s.price.toFixed(2)}</TableCell>
                      <TableCell className="text-right">
                        <span className={cn("font-number text-sm font-medium px-1.5 py-0.5 rounded", s.changeRate > 0 ? "bg-rise/10 text-rise" : s.changeRate < 0 ? "bg-fall/10 text-fall" : "bg-muted text-muted-foreground")}>
                          {s.changeRate > 0 ? "+" : ""}{s.changeRate.toFixed(2)}%
                        </span>
                      </TableCell>
                      <TableCell><Badge variant="secondary" className="text-xs">{s.sector}</Badge></TableCell>
                      <TableCell className="text-right text-muted-foreground text-sm hidden md:table-cell">{s.volume}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>

        {/* 基金净值 */}
        <TabsContent value="fund">
          <Card>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>基金名称</TableHead>
                    <TableHead className="text-right">最新净值</TableHead>
                    <TableHead className="text-right">日涨跌幅</TableHead>
                    <TableHead>类型</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {FUNDS.map((f) => (
                    <TableRow key={f.code}>
                      <TableCell>
                        <div className="font-medium text-sm">{f.name}</div>
                        <div className="text-xs text-muted-foreground">{f.code}</div>
                      </TableCell>
                      <TableCell className="text-right font-number font-semibold">{f.nav.toFixed(4)}</TableCell>
                      <TableCell className="text-right">
                        <span className={cn("font-number text-sm font-medium px-1.5 py-0.5 rounded", f.changeRate > 0 ? "bg-rise/10 text-rise" : f.changeRate < 0 ? "bg-fall/10 text-fall" : "bg-muted text-muted-foreground")}>
                          {f.changeRate > 0 ? "+" : ""}{f.changeRate.toFixed(2)}%
                        </span>
                      </TableCell>
                      <TableCell><Badge variant="outline" className="text-xs">{f.type}</Badge></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>

        {/* 涨幅榜 */}
        <TabsContent value="rise">
          <Card>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>排名</TableHead>
                    <TableHead>名称</TableHead>
                    <TableHead className="text-right">涨幅</TableHead>
                    <TableHead className="text-right">最新价</TableHead>
                    <TableHead>板块</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {[...STOCKS].sort((a, b) => b.changeRate - a.changeRate).slice(0, 10).map((s, i) => (
                    <TableRow key={s.code}>
                      <TableCell className="font-number font-bold text-muted-foreground">{i + 1}</TableCell>
                      <TableCell>
                        <div className="font-medium text-sm">{s.name}</div>
                        <div className="text-xs text-muted-foreground">{s.code}</div>
                      </TableCell>
                      <TableCell className="text-right">
                        <span className="bg-rise/10 text-rise font-number text-sm font-bold px-1.5 py-0.5 rounded">
                          +{s.changeRate.toFixed(2)}%
                        </span>
                      </TableCell>
                      <TableCell className="text-right font-number">{s.price.toFixed(2)}</TableCell>
                      <TableCell><Badge variant="secondary" className="text-xs">{s.sector}</Badge></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>

        {/* 跌幅榜 */}
        <TabsContent value="fall">
          <Card>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>排名</TableHead>
                    <TableHead>名称</TableHead>
                    <TableHead className="text-right">跌幅</TableHead>
                    <TableHead className="text-right">最新价</TableHead>
                    <TableHead>板块</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {[...STOCKS].sort((a, b) => a.changeRate - b.changeRate).slice(0, 10).map((s, i) => (
                    <TableRow key={s.code}>
                      <TableCell className="font-number font-bold text-muted-foreground">{i + 1}</TableCell>
                      <TableCell>
                        <div className="font-medium text-sm">{s.name}</div>
                        <div className="text-xs text-muted-foreground">{s.code}</div>
                      </TableCell>
                      <TableCell className="text-right">
                        <span className="bg-fall/10 text-fall font-number text-sm font-bold px-1.5 py-0.5 rounded">
                          {s.changeRate.toFixed(2)}%
                        </span>
                      </TableCell>
                      <TableCell className="text-right font-number">{s.price.toFixed(2)}</TableCell>
                      <TableCell><Badge variant="secondary" className="text-xs">{s.sector}</Badge></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
