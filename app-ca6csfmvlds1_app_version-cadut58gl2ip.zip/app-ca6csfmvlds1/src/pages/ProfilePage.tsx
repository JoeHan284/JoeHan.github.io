import { useState, useEffect } from "react";
import { Navigate } from "react-router-dom";
import { User, Shield, Settings, History, Save, Eye, EyeOff } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/db/supabase";
import { fetchTransactions } from "@/api/api";
import { formatCNY, formatDate, transactionTypeLabel, transactionStatusLabel } from "@/lib/utils";
import type { Transaction } from "@/types/types";
import { toast } from "sonner";

export default function ProfilePage() {
  const { user, profile, loading: authLoading, refreshProfile } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loadingTx, setLoadingTx] = useState(true);

  // 个人信息编辑
  const [username, setUsername] = useState("");
  const [saving, setSaving] = useState(false);

  // 修改密码
  const [oldPwd, setOldPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [confirmPwd, setConfirmPwd] = useState("");
  const [showPwd, setShowPwd] = useState(false);
  const [changingPwd, setChangingPwd] = useState(false);

  // 投资偏好
  const [riskPref, setRiskPref] = useState("");
  const [horizonPref, setHorizonPref] = useState("");
  const [savingPref, setSavingPref] = useState(false);

  useEffect(() => {
    if (!user) return;
    setUsername(profile?.username ?? "");
    setRiskPref(profile?.risk_preference ?? "");
    setHorizonPref(profile?.investment_horizon ?? "");
    fetchTransactions(user.id)
      .then(setTransactions)
      .finally(() => setLoadingTx(false));
  }, [user, profile]);

  if (!authLoading && !user) return <Navigate to="/login" replace />;

  const handleSaveProfile = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({ username: username || null })
      .eq("id", user.id);
    setSaving(false);
    if (error) { toast.error("保存失败，请重试"); return; }
    await refreshProfile();
    toast.success("个人信息已更新");
  };

  const handleChangePwd = async () => {
    if (!newPwd || !confirmPwd) { toast.error("请填写新密码"); return; }
    if (newPwd.length < 8) { toast.error("新密码长度不能少于8位"); return; }
    if (newPwd !== confirmPwd) { toast.error("两次输入的密码不一致"); return; }
    setChangingPwd(true);
    const { error } = await supabase.auth.updateUser({ password: newPwd });
    setChangingPwd(false);
    if (error) { toast.error(error.message); return; }
    toast.success("密码已修改成功");
    setOldPwd(""); setNewPwd(""); setConfirmPwd("");
  };

  const handleSavePref = async () => {
    if (!user) return;
    setSavingPref(true);
    const { error } = await supabase
      .from("profiles")
      .update({
        risk_preference: riskPref || null,
        investment_horizon: horizonPref || null,
      })
      .eq("id", user.id);
    setSavingPref(false);
    if (error) { toast.error("保存失败，请重试"); return; }
    await refreshProfile();
    toast.success("投资偏好已更新");
  };

  if (authLoading) {
    return (
      <div className="p-4 md:p-6 max-w-3xl mx-auto space-y-4">
        <Skeleton className="h-8 w-40" />
        <Skeleton className="h-32" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto min-w-0 space-y-6">
      <div>
        <h1 className="text-lg font-bold text-balance">用户中心</h1>
        <p className="text-sm text-muted-foreground">管理您的账户信息与投资偏好</p>
      </div>

      {/* 用户信息卡片 */}
      <Card>
        <CardContent className="p-4 md:p-6">
          <div className="flex items-center gap-4">
            <Avatar className="h-14 w-14">
              <AvatarFallback className="bg-primary text-primary-foreground text-xl">
                {(profile?.username ?? profile?.email ?? "U")[0].toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-base truncate">{profile?.username ?? "未设置用户名"}</div>
              <div className="text-sm text-muted-foreground truncate">{profile?.email}</div>
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                <Badge variant="secondary" className="text-xs">
                  注册于 {profile?.created_at ? formatDate(profile.created_at) : "—"}
                </Badge>
                {profile?.risk_preference && (
                  <Badge variant="outline" className="text-xs">
                    {profile.risk_preference === "conservative" ? "保守型" : profile.risk_preference === "moderate" ? "稳健型" : "进取型"}
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="info">
        <TabsList className="w-full">
          <TabsTrigger value="info" className="flex-1 text-xs">
            <User className="h-3.5 w-3.5 mr-1 hidden md:inline" />个人信息
          </TabsTrigger>
          <TabsTrigger value="security" className="flex-1 text-xs">
            <Shield className="h-3.5 w-3.5 mr-1 hidden md:inline" />账户安全
          </TabsTrigger>
          <TabsTrigger value="pref" className="flex-1 text-xs">
            <Settings className="h-3.5 w-3.5 mr-1 hidden md:inline" />投资偏好
          </TabsTrigger>
          <TabsTrigger value="history" className="flex-1 text-xs">
            <History className="h-3.5 w-3.5 mr-1 hidden md:inline" />交易记录
          </TabsTrigger>
        </TabsList>

        {/* 个人信息 */}
        <TabsContent value="info" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">修改个人信息</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="username">用户名</Label>
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="请输入用户名"
                />
              </div>
              <div className="space-y-1.5">
                <Label>邮箱</Label>
                <Input value={profile?.email ?? ""} disabled className="bg-muted" />
              </div>
              <Button onClick={handleSaveProfile} disabled={saving} className="gap-1.5">
                <Save className="h-4 w-4" />{saving ? "保存中..." : "保存修改"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 账户安全 */}
        <TabsContent value="security" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">修改密码</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="old-pwd">新密码</Label>
                <div className="relative">
                  <Input
                    id="old-pwd"
                    type={showPwd ? "text" : "password"}
                    value={newPwd}
                    onChange={(e) => setNewPwd(e.target.value)}
                    placeholder="至少8位字符"
                    className="pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPwd(!showPwd)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="confirm-pwd">确认新密码</Label>
                <Input
                  id="confirm-pwd"
                  type={showPwd ? "text" : "password"}
                  value={confirmPwd}
                  onChange={(e) => setConfirmPwd(e.target.value)}
                  placeholder="再次输入新密码"
                />
              </div>
              <Button onClick={handleChangePwd} disabled={changingPwd} className="gap-1.5">
                <Shield className="h-4 w-4" />{changingPwd ? "修改中..." : "修改密码"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 投资偏好 */}
        <TabsContent value="pref" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">投资偏好设置</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label>风险偏好</Label>
                <Select value={riskPref} onValueChange={setRiskPref}>
                  <SelectTrigger>
                    <SelectValue placeholder="请选择风险偏好" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="conservative">保守型 — 追求稳定收益，不愿承担较大波动</SelectItem>
                    <SelectItem value="moderate">稳健型 — 平衡收益与风险，适度承受波动</SelectItem>
                    <SelectItem value="aggressive">进取型 — 追求高收益，可承受较大波动</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>投资期限偏好</Label>
                <Select value={horizonPref} onValueChange={setHorizonPref}>
                  <SelectTrigger>
                    <SelectValue placeholder="请选择投资期限" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="short">短期（1年以内）</SelectItem>
                    <SelectItem value="medium">中期（1-5年）</SelectItem>
                    <SelectItem value="long">长期（5年以上）</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleSavePref} disabled={savingPref} className="gap-1.5">
                <Save className="h-4 w-4" />{savingPref ? "保存中..." : "保存偏好"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 交易记录 */}
        <TabsContent value="history" className="mt-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">交易记录</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {loadingTx ? (
                <div className="p-4 space-y-2">
                  {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-12" />)}
                </div>
              ) : transactions.length === 0 ? (
                <div className="py-12 text-center text-muted-foreground text-sm">
                  <History className="h-8 w-8 mx-auto mb-2 opacity-40" />
                  暂无交易记录
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>时间</TableHead>
                        <TableHead>类型</TableHead>
                        <TableHead>产品</TableHead>
                        <TableHead className="text-right">金额</TableHead>
                        <TableHead>状态</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {transactions.map((tx) => (
                        <TableRow key={tx.id}>
                          <TableCell className="text-xs whitespace-nowrap">{formatDate(tx.created_at)}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="text-xs">{transactionTypeLabel(tx.transaction_type)}</Badge>
                          </TableCell>
                          <TableCell className="text-sm">{tx.product_name}</TableCell>
                          <TableCell className="text-right font-number font-medium">{formatCNY(tx.amount)}</TableCell>
                          <TableCell>
                            <Badge variant="secondary" className="text-xs">{transactionStatusLabel(tx.status)}</Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}