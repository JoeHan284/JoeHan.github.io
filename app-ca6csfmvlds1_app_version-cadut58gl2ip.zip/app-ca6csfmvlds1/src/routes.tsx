import type { ReactNode } from 'react';
import Layout from '@/components/layouts/Layout';
import HomePage from '@/pages/HomePage';
import LoginPage from '@/pages/LoginPage';
import AssetsPage from '@/pages/AssetsPage';
import MarketPage from '@/pages/MarketPage';
import ProductsPage from '@/pages/ProductsPage';
import ProductDetailPage from '@/pages/ProductDetailPage';
import PlanningPage from '@/pages/PlanningPage';
import NewsPage from '@/pages/NewsPage';
import ArticleDetailPage from '@/pages/ArticleDetailPage';
import ProfilePage from '@/pages/ProfilePage';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  public?: boolean;
  children?: RouteConfig[];
}

export const routes: RouteConfig[] = [
  {
    name: '登录',
    path: '/login',
    element: <LoginPage />,
    public: true,
  },
  {
    name: '主布局',
    path: '/',
    element: <Layout />,
    public: true,
    children: [
      { name: '首页', path: '', element: <HomePage />, public: true },
      { name: '资产管理', path: 'assets', element: <AssetsPage /> },
      { name: '市场行情', path: 'market', element: <MarketPage />, public: true },
      { name: '投资产品', path: 'products', element: <ProductsPage />, public: true },
      { name: '产品详情', path: 'products/:id', element: <ProductDetailPage />, public: true },
      { name: '财富规划', path: 'planning', element: <PlanningPage />, public: true },
      { name: '资讯中心', path: 'news', element: <NewsPage />, public: true },
      { name: '文章详情', path: 'news/:id', element: <ArticleDetailPage />, public: true },
      { name: '用户中心', path: 'profile', element: <ProfilePage /> },
    ],
  },
];
