
-- 启用 UUID 扩展
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── 用户角色 ─────────────────────────────────────────────
CREATE TYPE public.user_role AS ENUM ('user', 'admin');

-- ─── 用户资料表 ───────────────────────────────────────────
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  phone text,
  username text,
  full_name text,
  avatar_url text,
  role public.user_role NOT NULL DEFAULT 'user',
  risk_preference text CHECK (risk_preference IN ('conservative','moderate','aggressive')),
  investment_horizon text CHECK (investment_horizon IN ('short','medium','long')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 新用户自动同步
CREATE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, email, phone, role)
  VALUES (NEW.id, NEW.email, NEW.phone, 'user'::public.user_role);
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- RLS helper
CREATE FUNCTION public.get_user_role(uid uuid)
RETURNS public.user_role LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  SELECT role FROM public.profiles WHERE id = uid;
$$;

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins_full_profiles" ON public.profiles FOR ALL TO authenticated
  USING (public.get_user_role(auth.uid()) = 'admin'::public.user_role);

CREATE POLICY "users_view_own_profile" ON public.profiles FOR SELECT TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "users_update_own_profile" ON public.profiles FOR UPDATE TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (role IS NOT DISTINCT FROM public.get_user_role(auth.uid()));

-- ─── 理财产品表 ───────────────────────────────────────────
CREATE TYPE public.product_type AS ENUM ('money_market','bond_fund','stock_fund','fixed_income');
CREATE TYPE public.risk_level AS ENUM ('R1','R2','R3','R4','R5');

CREATE TABLE public.products (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  code text NOT NULL UNIQUE,
  product_type public.product_type NOT NULL,
  risk_level public.risk_level NOT NULL DEFAULT 'R2',
  annual_return numeric(6,2) NOT NULL DEFAULT 0,
  min_purchase numeric(12,2) NOT NULL DEFAULT 100,
  nav numeric(10,4) NOT NULL DEFAULT 1.0000,
  description text,
  fund_company text,
  inception_date date,
  total_assets numeric(18,2),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "products_public_read" ON public.products FOR SELECT TO anon, authenticated USING (is_active = true);
CREATE POLICY "admins_manage_products" ON public.products FOR ALL TO authenticated
  USING (public.get_user_role(auth.uid()) = 'admin'::public.user_role);

-- ─── 产品净值历史 ─────────────────────────────────────────
CREATE TABLE public.product_nav_history (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  nav numeric(10,4) NOT NULL,
  date date NOT NULL,
  UNIQUE(product_id, date)
);

ALTER TABLE public.product_nav_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "nav_history_public_read" ON public.product_nav_history FOR SELECT TO anon, authenticated USING (true);

-- ─── 用户资产表 ───────────────────────────────────────────
CREATE TYPE public.asset_type AS ENUM ('stock','fund','bond','deposit');

CREATE TABLE public.assets (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  code text,
  asset_type public.asset_type NOT NULL,
  quantity numeric(18,4) NOT NULL DEFAULT 0,
  cost_price numeric(12,4) NOT NULL DEFAULT 0,
  current_price numeric(12,4) NOT NULL DEFAULT 0,
  market_value numeric(18,2) NOT NULL DEFAULT 0,
  profit_loss numeric(18,2) NOT NULL DEFAULT 0,
  profit_loss_rate numeric(8,4) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.assets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "users_own_assets" ON public.assets FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "admins_view_assets" ON public.assets FOR SELECT TO authenticated
  USING (public.get_user_role(auth.uid()) = 'admin'::public.user_role);

-- ─── 交易记录表 ───────────────────────────────────────────
CREATE TYPE public.transaction_type AS ENUM ('buy','sell','deposit','withdraw');
CREATE TYPE public.transaction_status AS ENUM ('pending','completed','cancelled');

CREATE TABLE public.transactions (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  product_id uuid REFERENCES public.products(id),
  product_name text NOT NULL,
  transaction_type public.transaction_type NOT NULL,
  amount numeric(18,2) NOT NULL,
  quantity numeric(18,4),
  price numeric(12,4),
  status public.transaction_status NOT NULL DEFAULT 'completed',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "users_own_transactions" ON public.transactions FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "admins_view_transactions" ON public.transactions FOR SELECT TO authenticated
  USING (public.get_user_role(auth.uid()) = 'admin'::public.user_role);

-- ─── 资讯文章表 ───────────────────────────────────────────
CREATE TYPE public.article_category AS ENUM ('news','analysis','strategy');

CREATE TABLE public.articles (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  title text NOT NULL,
  summary text,
  content text NOT NULL DEFAULT '',
  category public.article_category NOT NULL DEFAULT 'news',
  author text,
  cover_image text,
  view_count integer NOT NULL DEFAULT 0,
  is_published boolean NOT NULL DEFAULT true,
  published_at timestamptz DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.articles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "articles_public_read" ON public.articles FOR SELECT TO anon, authenticated USING (is_published = true);
CREATE POLICY "admins_manage_articles" ON public.articles FOR ALL TO authenticated
  USING (public.get_user_role(auth.uid()) = 'admin'::public.user_role);
